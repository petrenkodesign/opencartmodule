<?php
// Heading
$_['heading_title']    = 'Пользовательский конструктор досок';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Успех: Настройки "Конструктора досок" успешно изменены!';
$_['text_edit']        = 'Редактировать модуль';

// Entry
$_['entry_page_title']           = 'Заголовок страницы';
$_['entry_product_name']         = 'Имя продукта';
$_['entry_product_quantity']     = 'Количество';
$_['entry_product_price']        = 'Цена';
$_['entry_product_minimum']      = 'Минимальное количество';
$_['entry_product_shipping']     = 'Доставка';
$_['entry_product_code']         = 'Модель';
$_['entry_product_points']       = 'Бонусные очки';
$_['entry_product_availability'] = 'Доступность';
$_['entry_product_instock']      = 'В наличии';
$_['entry_product_outstock']     = 'Нет в наличии';
$_['entry_product_top']          = 'Верхнее меню';
$_['entry_product_bottom']       = 'Нижнее меню';
$_['entry_status']               = 'Статус';

// Error
$_['error_permission'] = 'Внимание: У Вас нет прав для настроек модуля!';
$_['error_page_title'] = 'Внимание: Заголовок страницы обязателеный параметр!';

// addons
$_['text_none'] = '--- нет ---';
$_['button_save'] = 'Сохранить';
$_['button_cancel'] = 'Отмена';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
