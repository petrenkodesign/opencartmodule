<?php
// Heading
$_['heading_title']    = 'Конструктор досок';
$_['button_cart']    = 'Добавить в корзину';
