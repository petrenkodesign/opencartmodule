<?php
// Heading
$_['heading_title']    = 'Custom board builder';
$_['button_cart']    = 'Add to cart';
