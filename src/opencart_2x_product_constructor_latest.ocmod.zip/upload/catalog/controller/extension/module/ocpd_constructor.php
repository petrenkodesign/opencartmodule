<?php
class ControllerExtensionModuleOcpdConstructor extends Controller {
  public function index() {

    $this->load->language('extension/module/ocpd_constructor'); // get langueges arrays
    $data['heading_title'] = $this->language->get('heading_title');
    $data['button_cart'] = $this->language->get('button_cart');

    $data['heading_title'] = $this->config->get('module_ocpd_page_title');

    $this->document->setTitle($data['heading_title']); // set page title
    // $this->document->addScript('catalog/view/javascript/jquery/magnific/jquery.magnific-popup.min.js');


    // set breadcrumbs data
    $data['breadcrumbs'][] = array(
        'text' => $this->language->get('text_home'),
        'href' => $this->url->link('common/home')
    );
    $data['breadcrumbs'][] = array(
        'text' => $data['heading_title'],
        'href' => $this->url->link('extension/module/ocpd_constructor')
    );

    $this->load->model('localisation/currency');
    $data['currency'] = $this->session->data['currency'];
    $data['currency_symbol'] = $this->model_localisation_currency->getCurrencyByCode($data['currency'])['symbol_left'];

    $data['local_code'] = $this->language->get('code');


    $this->load->model('catalog/product');
    $data['product_id'] = $this->config->get('module_ocpd_product_name');
    $data['product_info'] = $this->model_catalog_product->getProduct($data['product_id']);
    $data['product_info']['description'] = html_entity_decode($data['product_info']['description']);
    $data['product_options'] = $this->model_catalog_product->getProductOptions($data['product_id']);

    $this->document->setDescription($data['product_info']['meta_description']);
	  $this->document->setKeywords($data['product_info']['meta_keyword']);

    // get layers and activity status from module config
    if(isset($data['product_options'][0])) {
      for($i=0; $i<count($data['product_options']); $i++) {
        for($x=0; $x<count($data['product_options'][$i]['product_option_value']); $x++) {
          $opt_vid = $data['product_options'][$i]['product_option_value'][$x]['option_value_id'];

          $opt_ac_front_name = 'module_ocpd_option_box_'.$opt_vid;
          $data['product_options'][$i]['product_option_value'][$x]['acbox_value'] = $this->config->get($opt_ac_front_name);

          $opt_ly_front_name = 'module_ocpd_layer_image_'.$opt_vid;
          $data['product_options'][$i]['product_option_value'][$x]['var_layer_value'] = $this->config->get($opt_ly_front_name);
        }
      }
    }

    $data['header'] = $this->load->controller('common/header'); // page header include
    $data['content_top'] = $this->load->controller('common/content_top');
    $data['content_bottom'] = $this->load->controller('common/content_bottom');
    $data['footer'] = $this->load->controller('common/footer'); // footer header include
    $this->response->setOutput($this->load->view('extension/module/ocpd_constructor', $data)); // load and show page template

  }
}
?>
