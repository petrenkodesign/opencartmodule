<?php
class ControllerExtensionModuleOcpdConstructor extends Controller {
    private $error = array();

    public function index() {

        $this->load->language('extension/module/ocpd_constructor'); // get langueges arrays
        $data['heading_title']    = $this->language->get('heading_title');
        $data['text_extension']   = $this->language->get('heading_title');
        $data['text_success']     = $this->language->get('heading_title');
        $data['text_edit']        = $this->language->get('heading_title');

        // Entry
        $data['entry_page_title']           = $this->language->get('entry_page_title');
        $data['entry_product_name']         = $this->language->get('entry_product_name');
        $data['entry_product_quantity']     = $this->language->get('entry_product_quantity');
        $data['entry_product_price']        = $this->language->get('entry_product_price');
        $data['entry_product_minimum']      = $this->language->get('entry_product_minimum');
        $data['entry_product_shipping']     = $this->language->get('entry_product_shipping');
        $data['entry_product_code']         = $this->language->get('entry_product_code');
        $data['entry_product_points']       = $this->language->get('entry_product_points');
        $data['entry_product_availability'] = $this->language->get('entry_product_availability');
        $data['entry_product_instock']      = $this->language->get('entry_product_instock');
        $data['entry_product_outstock']     = $this->language->get('entry_product_outstock');
        $data['entry_product_top']          = $this->language->get('entry_product_top');
        $data['entry_product_bottom']       = $this->language->get('entry_product_bottom');
        $data['entry_status']               = $this->language->get('entry_status');

        // Error
        $data['error_permission'] = $this->language->get('error_permission');
        $data['error_page_title'] = $this->language->get('error_page_title');

        $data['text_none'] = $this->language->get('text_none');
        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');



        $this->document->setTitle($this->language->get('heading_title')); // include admin page title

        $this->load->model('setting/setting'); // load setting model
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) { // get POST variables and validate it
            $this->model_setting_setting->editSetting('module_ocpd', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success'); // set success message
            $this->response->redirect($this->url->link('extension/module/ocpd_constructor', 'token=' . $this->session->data['token'] . '&type=module', true));
        }

        if (isset($this->error['warning'])) { // include error message if get error
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        $data['breadcrumbs'] = array(); // set breadcrumbs data
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'token=' . $this->session->data['token'] . '&type=module', true)
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/ocpd_constructor', 'token=' . $this->session->data['token'], true)
        );

        // set actions buttons data
        $data['action'] = $this->url->link('extension/module/ocpd_constructor', 'token=' . $this->session->data['token'], true);
        $data['cancel'] = $this->url->link('marketplace/extension', 'token=' . $this->session->data['token'] . '&type=module', true);

        $this->load->model('tool/image'); // get tool model for image resize
        // cap for image
        $data['no_image'] = $this->model_tool_image->resize('no_image.png', 100, 100);

        // Page title variables
        if (isset($this->request->post['module_ocpd_page_title'])) {
            $data['module_ocpd_page_title'] = $this->request->post['module_ocpd_page_title'];
        } else {
            $data['module_ocpd_page_title'] = $this->config->get('module_ocpd_page_title');
        }

        // Product name variables
        if (isset($this->request->post['module_ocpd_product_name'])) {
            $data['module_ocpd_product_name'] = $this->request->post['module_ocpd_product_name'];
        } else {
            $data['module_ocpd_product_name'] = $this->config->get('module_ocpd_product_name');
        }

        $products = $this->getAllProducts(); // get all products array
        // var_dump($products[0]);

        for($i=0; $i<count($products); $i++) {
          $data['products_names'][$i]['name'] = $products[$i]['name']; // get all products names
          $data['products_names'][$i]['id'] = $products[$i]['product_id'];
          if($products[$i]['product_id'] == $data['module_ocpd_product_name']) $data['sel_product'] = $products[$i]; // get selected product information
        }

        if(isset($data['sel_product'])) {
          $data['sel_product']['image'] = $this->model_tool_image->resize($data['sel_product']['image'], 200, 200); // get link on resized image
          $data['sel_product_option'] = $this->getOptions($data['sel_product']['product_id']); // get product options
          if(isset($this->session->data['currency'])) $data['sel_product']['currency'] = $this->session->data['currency'];
          $data['sel_product']['price'] = number_format($data['sel_product']['price'], 2, '.', '');
        }
        else $data['sel_product'] = '';


        // Product option activity and layers
        if(isset($data['sel_product_option'])) {
          for($i=0; $i<count($data['sel_product_option']); $i++) {
            for($x=0; $x<count($data['sel_product_option'][$i]['option_value']); $x++) {

              $opt_vid = $data['sel_product_option'][$i]['option_value'][$x]['option_value_id'];

              // product activity checkbox
              $opt_ac_front_name = 'module_ocpd_option_box_'.$opt_vid;
              $data['sel_product_option'][$i]['option_value'][$x]['acbox_name']  = $opt_ac_front_name;
              if (isset($this->request->post[$opt_ac_front_name])) {
                  $data[$opt_ac_front_name] = $this->request->post[$opt_ac_front_name];
              } else {
                  $data[$opt_ac_front_name] = $this->config->get($opt_ac_front_name);
              }
              $data['sel_product_option'][$i]['option_value'][$x]['acbox_value'] = $data[$opt_ac_front_name];

              // product layer image
              $opt_ly_front_name = 'module_ocpd_layer_image_'.$opt_vid;
              $data['sel_product_option'][$i]['option_value'][$x]['var_layer_name']  = $opt_ly_front_name;
              if (isset($this->request->post[$opt_ly_front_name])) {
                  $data[$opt_ly_front_name] = $this->request->post[$opt_ly_front_name];
              } else {
                  $data[$opt_ly_front_name] = $this->config->get($opt_ly_front_name);
              }
              // set layer value by image url
              $data['sel_product_option'][$i]['option_value'][$x]['var_layer_value'] = $data[$opt_ly_front_name];

              // change option ico size
              if(!$data['sel_product_option'][$i]['option_value'][$x]['image']) $data['sel_product_option'][$i]['option_value'][$x]['image'] = $data['no_image'];
              else {
                $this_image_size = getimagesize(DIR_IMAGE . $data['sel_product_option'][$i]['option_value'][$x]['image']);
                $height = $this_image_size[1]/($this_image_size[0]/50);
                $height = round($height, 2);
                $data['sel_product_option'][$i]['option_value'][$x]['image'] = $this->model_tool_image->resize($data['sel_product_option'][$i]['option_value'][$x]['image'], 50, $height);
              }
            }
          }
        }
        else $data['sel_product_option'] = '';


        // Product top menu selector
        if (isset($this->request->post['module_ocpd_page_top_menu'])) {
            $data['module_ocpd_page_top_menu'] = $this->request->post['module_ocpd_page_top_menu'];
        } else {
            $data['module_ocpd_page_top_menu'] = $this->config->get('module_ocpd_page_top_menu');
        }
        if (isset($this->request->post['module_ocpd_page_top_menu_order'])) {
            $data['module_ocpd_page_top_menu_order'] = $this->request->post['module_ocpd_page_top_menu_order'];
        } else {
            $data['module_ocpd_page_top_menu_order'] = $this->config->get('module_ocpd_page_top_menu_order');
        }
        
        // Product bottom menu selector
        if (isset($this->request->post['module_ocpd_page_bottom_menu'])) {
            $data['module_ocpd_page_bottom_menu'] = $this->request->post['module_ocpd_page_bottom_menu'];
        } else {
            $data['module_ocpd_page_bottom_menu'] = $this->config->get('module_ocpd_page_bottom_menu');
        }


        $data['header'] = $this->load->controller('common/header'); // admin page header include
        $data['column_left'] = $this->load->controller('common/column_left'); // admin page left menu include
        $data['footer'] = $this->load->controller('common/footer'); // admin footer header include
        $this->response->setOutput($this->load->view('extension/module/ocpd_constructor', $data)); // load and show page template
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/module/ocpd_constructor')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        if (empty($this->request->post['module_ocpd_page_title'])) {
            $this->error['warning'] = $this->language->get('error_page_title');
        }
        return !$this->error;
    }

    protected function getOptions($product_id) {
      $product_option_data = array();
      $product_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_option po LEFT JOIN `" . DB_PREFIX . "option` o ON (po.option_id = o.option_id) LEFT JOIN " . DB_PREFIX . "option_description od ON (o.option_id = od.option_id) WHERE po.product_id = '" . (int)$product_id . "' AND od.language_id = '" . (int)$this->config->get('config_language_id') . "' ORDER BY o.sort_order");

      foreach ($product_option_query->rows as $product_option) {
      	if ($product_option['type'] == 'radio') {
      		$product_option_value_data = array();

      		$product_option_value_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_option_value pov LEFT JOIN " . DB_PREFIX . "option_value ov ON (pov.option_value_id = ov.option_value_id) LEFT JOIN " . DB_PREFIX . "option_value_description ovd ON (ov.option_value_id = ovd.option_value_id) WHERE pov.product_id = '" . (int)$product_id . "' AND pov.product_option_id = '" . (int)$product_option['product_option_id'] . "' AND ovd.language_id = '" . (int)$this->config->get('config_language_id') . "' ORDER BY ov.sort_order");

      		foreach ($product_option_value_query->rows as $product_option_value) {
      			$product_option_value_data[] = array(
      				'product_option_value_id' => $product_option_value['product_option_value_id'],
      				'option_value_id'         => $product_option_value['option_value_id'],
      				'name'                    => $product_option_value['name'],
      				'image'                   => $product_option_value['image'],
      				'quantity'                => $product_option_value['quantity'],
      				'subtract'                => $product_option_value['subtract'],
      				'price'                   => $product_option_value['price'],
      				'price_prefix'            => $product_option_value['price_prefix'],
      				'weight'                  => $product_option_value['weight'],
      				'weight_prefix'           => $product_option_value['weight_prefix']
      			);
      		}

      		$product_option_data[] = array(
      			'product_option_id' => $product_option['product_option_id'],
      			'option_id'         => $product_option['option_id'],
      			'name'              => $product_option['name'],
      			'type'              => $product_option['type'],
      			'option_value'      => $product_option_value_data,
      			'required'          => $product_option['required']
      		);
      	}
      }
      return $product_option_data;
    }

    protected function getAllProducts() {
      $this->load->model('catalog/product'); // load products model
      $products = $this->model_catalog_product->getProducts();
      return $products;
    }

}

?>
