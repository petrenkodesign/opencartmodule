<?php
// Heading
$_['heading_title']    = 'Custom board builder';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified "Custom board builder" module!';
$_['text_edit']        = 'Edit Module';

// Entry
$_['entry_page_title']           = 'Page title';
$_['entry_product_name']         = 'Product name';
$_['entry_product_quantity']     = 'Quantity';
$_['entry_product_price']        = 'Price';
$_['entry_product_minimum']      = 'Minimum quantity';
$_['entry_product_shipping']     = 'Shipping';
$_['entry_product_code']         = 'Product Code';
$_['entry_product_points']       = 'Reward Points';
$_['entry_product_availability'] = 'Availability';
$_['entry_product_instock']      = 'In stock';
$_['entry_product_outstock']     = 'Out stock';
$_['entry_product_top']          = 'Top menu';
$_['entry_product_bottom']       = 'Bottom menu';
$_['entry_status']               = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module!';
$_['error_page_title'] = 'Page title required!';

// addons
$_['text_none'] = '--- none ---';
$_['button_save'] = 'Save';
$_['button_cancel'] = 'Cancel';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
